

class Payload:
    # The init method or constructor
    def __init__(self, login, application_data, quote):
        self.login = login
        self.application_data = application_data
        self.quote = quote

    def to_json(self):
        return '{"Login": %s, ' \
               '"OSPMessage": %s,' \
               '"ApplicationData": %s}' % \
               (self.login.to_json(),
                self.quote.to_json(),
                self.application_data.to_json())
